export declare function merge(...sets: Array<string>): string;
export declare function subexp(str: string): string;
export declare function typeOf(o: any): string;
export declare function toUpperCase(str: string): string;
export declare function toArray(obj: any): Array<any>;
export declare function assign(target: object, source: any): any;
