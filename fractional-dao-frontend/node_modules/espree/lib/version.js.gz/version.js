const version = "10.4.0";

export default version;
