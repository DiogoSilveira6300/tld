"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DEPRECATED_ALIASES = void 0;
const DEPRECATED_ALIASES = exports.DEPRECATED_ALIASES = {
  ModuleDeclaration: "ImportOrExportDeclaration"
};

//# sourceMappingURL=deprecated-aliases.js.map
