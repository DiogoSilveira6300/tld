"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = cloneDeepWithoutLoc;
var _cloneNode = require("./cloneNode.js");
function cloneDeepWithoutLoc(node) {
  return (0, _cloneNode.default)(node, true, true);
}

//# sourceMappingURL=cloneDeepWithoutLoc.js.map
