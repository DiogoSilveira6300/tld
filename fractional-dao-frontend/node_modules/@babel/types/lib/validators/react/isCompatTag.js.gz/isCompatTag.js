"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = isCompatTag;
function isCompatTag(tagName) {
  return !!tagName && /^[a-z]/.test(tagName);
}

//# sourceMappingURL=isCompatTag.js.map
