module.exports = function import_(filepath) {
  return import(filepath);
};
0 && 0;

//# sourceMappingURL=import.cjs.map
