export { WebSocket } from "ws";
//# sourceMappingURL=ws.d.ts.map