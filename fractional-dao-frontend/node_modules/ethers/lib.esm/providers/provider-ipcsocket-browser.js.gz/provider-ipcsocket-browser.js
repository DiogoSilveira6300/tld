const IpcSocketProvider = undefined;
export { IpcSocketProvider };
//# sourceMappingURL=provider-ipcsocket-browser.js.map