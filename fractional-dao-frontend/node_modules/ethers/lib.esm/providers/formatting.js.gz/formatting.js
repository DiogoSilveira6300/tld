/**
 *  About provider formatting?
 *
 *  @_section: api/providers/formatting:Formatting  [provider-formatting]
 */
;
;
export {};
//# sourceMappingURL=formatting.js.map