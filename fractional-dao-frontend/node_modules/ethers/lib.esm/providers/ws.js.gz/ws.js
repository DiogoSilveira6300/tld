export { WebSocket } from "ws";
//# sourceMappingURL=ws.js.map