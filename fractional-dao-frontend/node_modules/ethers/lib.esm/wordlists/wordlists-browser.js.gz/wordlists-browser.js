import { LangEn } from "./lang-en.js";
export const wordlists = {
    en: LangEn.wordlist(),
};
//# sourceMappingURL=wordlists-browser.js.map