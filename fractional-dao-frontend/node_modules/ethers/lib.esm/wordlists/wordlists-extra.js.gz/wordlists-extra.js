export { LangCz } from "./lang-cz.js";
export { LangEs } from "./lang-es.js";
export { LangFr } from "./lang-fr.js";
export { LangJa } from "./lang-ja.js";
export { LangKo } from "./lang-ko.js";
export { LangIt } from "./lang-it.js";
export { LangPt } from "./lang-pt.js";
export { LangZh } from "./lang-zh.js";
//# sourceMappingURL=wordlists-extra.js.map