"use strict";
/* Do NOT modify this file; see /src.ts/_admin/update-version.ts */
Object.defineProperty(exports, "__esModule", { value: true });
exports.version = void 0;
/**
 *  The current version of Ethers.
 */
exports.version = "6.15.0";
//# sourceMappingURL=_version.js.map