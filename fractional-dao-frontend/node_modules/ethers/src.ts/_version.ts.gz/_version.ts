/* Do NOT modify this file; see /src.ts/_admin/update-version.ts */

/**
 *  The current version of Ethers.
 */
export const version: string = "6.15.0";
