"use strict";
throw new Error('Incorrect usage. Import submodules instead');
//# sourceMappingURL=index.js.map