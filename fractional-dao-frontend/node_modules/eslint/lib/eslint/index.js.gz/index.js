"use strict";

const { ESLint } = require("./eslint");
const { LegacyESLint } = require("./legacy-eslint");

module.exports = {
	ESLint,
	LegacyESLint,
};
