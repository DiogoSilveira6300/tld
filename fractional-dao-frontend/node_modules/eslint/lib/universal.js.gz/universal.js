/**
 * @fileoverview exports for browsers
 * @author 唯然<weiran.zsd@outlook.com>
 */

"use strict";

const { Linter } = require("./linter/linter");

module.exports = { Linter };
