"use strict";

const SourceCode = require("./source-code");

module.exports = {
	SourceCode,
};
