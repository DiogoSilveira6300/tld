"use strict";

const RuleTester = require("./rule-tester");

module.exports = {
	RuleTester,
};
