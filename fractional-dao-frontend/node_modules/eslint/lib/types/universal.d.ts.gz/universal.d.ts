/**
 * @fileoverview typings for "eslint/universal" module
 * @author 唯然<weiran.zsd@outlook.com>
 */

export { Linter } from "./index";
