Gerneated Code (ESM)
====================

Do not modify code in this folder.

See `/src.ts/` and `/tsconfig.esm.json`.
