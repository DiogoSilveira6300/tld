Gerneated Code (CommonJS)
=========================

Do not modify code in this folder.

See `/src.ts/` and `/tsconfig.commonjs.json`.
