export declare function pkcs7Pad(data: Uint8Array): Uint8Array;
export declare function pkcs7Strip(data: Uint8Array): Uint8Array;
//# sourceMappingURL=padding.d.ts.map