import type { ParseAst, ParseAstAsync } from './rollup';

export const parseAst: ParseAst;
export const parseAstAsync: ParseAstAsync;
