import {
  require_react
} from "./chunk-NG4UJB3X.js";
import "./chunk-HKJ2B2AA.js";
export default require_react();
