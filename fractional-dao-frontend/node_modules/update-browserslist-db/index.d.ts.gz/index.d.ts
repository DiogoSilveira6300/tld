/**
 * Run update and print output to terminal.
 */
declare function updateDb(print?: (str: string) => void): void

export = updateDb
