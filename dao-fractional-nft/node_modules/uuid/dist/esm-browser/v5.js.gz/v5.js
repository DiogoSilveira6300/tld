import v35 from './v35.js';
import sha1 from './sha1.js';
var v5 = v35('v5', 0x50, sha1);
export default v5;