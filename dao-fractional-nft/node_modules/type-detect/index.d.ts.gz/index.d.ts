export default function typeDetect(obj: unknown): string;
