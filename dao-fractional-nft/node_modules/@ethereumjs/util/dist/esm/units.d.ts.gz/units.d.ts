/** Easy conversion from Gwei to wei */
export declare const GWEI_TO_WEI: bigint;
export declare function formatBigDecimal(numerator: bigint, denominator: bigint, maxDecimalFactor: bigint): string;
//# sourceMappingURL=units.d.ts.map