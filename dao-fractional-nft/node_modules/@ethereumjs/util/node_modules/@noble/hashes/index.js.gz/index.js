"use strict";
throw new Error('noble-hashes have no entry-point: consult README for usage');
//# sourceMappingURL=index.js.map