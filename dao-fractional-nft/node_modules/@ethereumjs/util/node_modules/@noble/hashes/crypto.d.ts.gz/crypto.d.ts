export declare const crypto: any;
//# sourceMappingURL=crypto.d.ts.map