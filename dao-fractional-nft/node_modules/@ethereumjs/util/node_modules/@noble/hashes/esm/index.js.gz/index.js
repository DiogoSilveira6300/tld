throw new Error('noble-hashes have no entry-point: consult README for usage');
export {};
//# sourceMappingURL=index.js.map