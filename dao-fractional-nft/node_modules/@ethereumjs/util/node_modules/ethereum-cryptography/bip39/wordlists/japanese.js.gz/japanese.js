"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.wordlist = void 0;
var japanese_1 = require("@scure/bip39/wordlists/japanese");
Object.defineProperty(exports, "wordlist", { enumerable: true, get: function () { return japanese_1.wordlist; } });
