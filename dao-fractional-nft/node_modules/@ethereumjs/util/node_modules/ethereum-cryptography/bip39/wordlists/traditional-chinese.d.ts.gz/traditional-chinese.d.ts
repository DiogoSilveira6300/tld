export { wordlist } from "@scure/bip39/wordlists/traditional-chinese";
