"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.wordlist = void 0;
var simplified_chinese_1 = require("@scure/bip39/wordlists/simplified-chinese");
Object.defineProperty(exports, "wordlist", { enumerable: true, get: function () { return simplified_chinese_1.wordlist; } });
