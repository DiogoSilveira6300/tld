"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.secp256k1 = void 0;
var secp256k1_1 = require("@noble/curves/secp256k1");
Object.defineProperty(exports, "secp256k1", { enumerable: true, get: function () { return secp256k1_1.secp256k1; } });
