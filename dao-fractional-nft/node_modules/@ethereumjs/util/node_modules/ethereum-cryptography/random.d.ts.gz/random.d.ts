export declare function getRandomBytesSync(bytes: number): Uint8Array;
export declare function getRandomBytes(bytes: number): Promise<Uint8Array>;
