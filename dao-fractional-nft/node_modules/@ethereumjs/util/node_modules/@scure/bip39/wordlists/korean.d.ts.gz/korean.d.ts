export declare const wordlist: string[];
//# sourceMappingURL=korean.d.ts.map