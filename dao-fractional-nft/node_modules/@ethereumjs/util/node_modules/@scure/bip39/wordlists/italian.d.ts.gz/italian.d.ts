export declare const wordlist: string[];
//# sourceMappingURL=italian.d.ts.map