"use strict";
/**
 *  About provider formatting?
 *
 *  @_section: api/providers/formatting:Formatting  [provider-formatting]
 */
Object.defineProperty(exports, "__esModule", { value: true });
;
;
//# sourceMappingURL=formatting.js.map