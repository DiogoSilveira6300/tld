/* Do NOT modify this file; see /src.ts/_admin/update-version.ts */
/**
 *  The current version of Ethers.
 */
export const version = "6.14.4";
//# sourceMappingURL=_version.js.map