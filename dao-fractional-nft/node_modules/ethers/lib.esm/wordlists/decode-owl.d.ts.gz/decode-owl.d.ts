/**
 *  @_ignore
 */
export declare function decode(data: string, subs: string): Array<string>;
/**
 *  @_ignore
 */
export declare function decodeOwl(data: string): Array<string>;
//# sourceMappingURL=decode-owl.d.ts.map