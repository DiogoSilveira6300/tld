/**
 *  The current version of Ethers.
 */
export declare const version: string;
//# sourceMappingURL=_version.d.ts.map