export declare const wordlist: string[];
//# sourceMappingURL=simplified-chinese.d.ts.map