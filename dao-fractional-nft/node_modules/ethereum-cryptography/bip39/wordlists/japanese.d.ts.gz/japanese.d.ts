export declare const wordlist: string[];
//# sourceMappingURL=japanese.d.ts.map