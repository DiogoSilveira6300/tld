/// <reference types="node" />
import { Hash } from "crypto";
export declare function createHashFunction(hashConstructor: () => Hash): (msg: Buffer) => Buffer;
//# sourceMappingURL=hash-utils.d.ts.map