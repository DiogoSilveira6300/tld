export * from "../../shims/hdkey-secp256k1v3";
//# sourceMappingURL=hdkey-secp256k1v3.d.ts.map