export { createHash, createHmac, randomBytes } from "crypto";
//# sourceMappingURL=hdkey-crypto.d.ts.map