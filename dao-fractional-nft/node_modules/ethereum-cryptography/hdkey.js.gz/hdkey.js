"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var hdkey = require("./vendor/hdkey-without-crypto");
exports.HDKey = hdkey;
//# sourceMappingURL=hdkey.js.map