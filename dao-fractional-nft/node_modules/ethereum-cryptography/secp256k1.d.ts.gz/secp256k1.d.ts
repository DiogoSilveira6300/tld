export declare function createPrivateKey(): Promise<Uint8Array>;
export declare function createPrivateKeySync(): Uint8Array;
export * from "secp256k1";
//# sourceMappingURL=secp256k1.d.ts.map