module.exports = {
  ArrayPrompt: require('./array'),
  AuthPrompt: require('./auth'),
  BooleanPrompt: require('./boolean'),
  NumberPrompt: require('./number'),
  StringPrompt: require('./string')
};
