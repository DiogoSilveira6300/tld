module.exports = require('./input');
