module.exports = require('../types/number');
